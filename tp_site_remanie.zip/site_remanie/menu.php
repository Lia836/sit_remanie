<ol>
    <li>Passer le test :</li>
    <ul><a href="index.php? page=2"></a>Test</li>
</ul>

<li>Lire le cours</li>
<ul>
<li> <a href="index.php? page=1"></a>Introduction</li>
<li> <a href="index.php? page=3"></a>Variables</li>
<li> <a href="index.php? page=4"></a>Tableaux</li>
<li> <a href="index.php? page=5"></a>Graphiques</li>

</ul>

<li>Lire le cours</a></li>
<ul>

<li> <a href="index.php? page=6"></a>TP</li>
</ul>
</ol>