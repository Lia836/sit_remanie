
<p>La s�quence pr�sent�e est un court extrait du module de cours de statistique
descriptive destin� aux �tudiant de licence de sciences de l'�ducation de l'universit� de Lille 3.<br />
A l'origine ce cours etait d�ploy� sous forme d'un cours magistral et d'un TD int�gr� de 13 X 3 heures.
La s�quence pr�sent�e ici est une reformulation fictive du premier cours et d'un exercice qui �tait 
initialement destin� � �tre r�alis� � la maison.</p>
<p>Les curieux pourront consulter les <a href="http://noce.univ-lille1.fr/projets/caron/stat/">TP r�els du cours </a></p>
<h2> La s�quence 0</h2>
<p>Cette s�quence est constitu�e de: </p>