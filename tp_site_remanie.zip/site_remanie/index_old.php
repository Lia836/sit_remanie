<html>
<head>
<?php
// ici le meta
include("meta.php");
?>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="pagetitle">
<?php
// ici l'entete
include("entete.php");
?>
</div>
<div class="newstitle">
<?php
// ici le chemin
include("chemin.php");
?>
</div>

<div
<div class="menu">
<?php
// ici le menu
include("menu.php");
?>
</div>
<div class="main">
<?php
// ici les pages
include("moteur.php");
?>
</div>
<div class="footer">
<?php
// ici le pied
include("pied.php");
?>
</div>
</body>
</html>
