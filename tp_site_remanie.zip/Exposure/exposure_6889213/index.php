<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--

Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Title      : Exposure
Version    : 1.0
Released   : 200800909
Description: A Web 2.0 design with fluid width suitable for blogs and small websites.

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Exposure by Free Css Templates</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<!-- start header -->
<div id="header">
	<div id="logo">
		<h1><a href="#">Exposure</a></h1>
		<p><a href="http://www.freecsstemplates.org/">By Free CSS Templates</a></p>
	</div>
	<div id="menu">
		<ul>
			<li class="current_page_item"><a href="#">Home</a></li>
			<li><a href="#">Blog</a></li>
			<li><a href="#">Photos</a></li>
			<li><a href="#">About</a></li>
			<li class="last"><a href="#">Contact</a></li>
		</ul>
	</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search" style="background: none;">
				<form id="searchform" method="get" action="">
					<div>
						<input type="text" name="s" id="s" size="15" />
						<br />
						<input type="submit" value="Search" />
					</div>
				</form>
			</li>
			<li id="categories">
				<h2>Categories</h2>
				<ul>
					<li><a href="#">Lorem Ipsum</a> (1) </li>
					<li><a href="#">Uncategorized</a> (4) </li>
				</ul>
			</li>
			<li>
				<h2>Lorem Ipsum Dolor</h2>
				<ul>
					<li><a href="#">Nulla luctus eleifend purus</a></li>
					<li><a href="#">Praesent scelerisque  </a></li>
					<li><a href="#">Ut nonummy rutrum sem</a></li>
					<li><a href="#">Pellentesque tempus   nulla</a></li>
					<li><a href="#">Fusce ultrices fringilla metus</a></li>
					<li><a href="#">Praesent mattis condimentum </a></li>
				</ul>
			</li>
			<li>
				<h2>Lorem Ipsum Dolor</h2>
				<ul>
					<li><a href="#">Nulla luctus eleifend purus</a></li>
					<li><a href="#">Praesent  scelerisque </a></li>
					<li><a href="#">Ut nonummy rutrum sem</a></li>
					<li><a href="#">Pellentesque tempus   nulla</a></li>
					<li><a href="#">Fusce ultrices fringilla metus</a></li>
					<li><a href="#">Praesent mattis condimentum </a></li>
				</ul>
			</li>
			<li>
				<h2>Lorem Ipsum Dolor</h2>
				<ul>
					<li><a href="#">Nulla luctus eleifend purus</a></li>
					<li><a href="#">Praesent  scelerisque </a></li>
					<li><a href="#">Ut nonummy rutrum sem</a></li>
					<li><a href="#">Pellentesque tempus   nulla</a></li>
					<li><a href="#">Fusce ultrices fringilla metus</a></li>
					<li><a href="#">Praesent mattis condimentum </a></li>
				</ul>
			</li>
			<li>
				<h2>Lorem Ipsum Dolor</h2>
				<ul>
					<li><a href="#">Nulla luctus eleifend purus</a></li>
					<li><a href="#">Praesent  scelerisque </a></li>
					<li><a href="#">Ut nonummy rutrum sem</a></li>
					<li><a href="#">Pellentesque tempus   nulla</a></li>
					<li><a href="#">Fusce ultrices fringilla metus</a></li>
					<li><a href="#">Praesent mattis condimentum </a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<!-- start content -->
	<div id="content">
		<div class="post">
			<div class="title">
				<h2><a href="#">About this Template</a></h2>
				<p><small>Posted on August 20th, 2007 by <a href="#">Free CSS Templates</a></small></p>
			</div>
			<div class="entry">
				<p>This is <strong>Exposure</strong>, a free, fully standards-compliant CSS template designed by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>. This free template is released under a <a href="http://creativecommons.org/licenses/by/2.5/">Creative Commons Attributions 2.5</a> license, so you're pretty much free to do whatever you want with it (even use it commercially) provided you keep the links in the footer intact. Aside from that, have fun with it :)</p>
				<p>This template is also available as a <a href="http://www.freewpthemes.net/preview/exposure">WordPress theme</a> at <a href="http://www.freewpthemes.net/">Free WordPress Themes</a>.</p>
			</div>
			<p class="links"><a href="#" class="more">Read More</a> <a href="#" class="comments">No Comments</a></p>
		</div>
		<div class="post">
			<div class="title">
				<h2><a href="#">Etiam rhoncus volutpat</a></h2>
				<p><small>Posted on August 20th, 2007 by <a href="#">Free CSS Templates</a></small></p>
			</div>
			<div class="entry">
				<p>Maecenas pede nisl, elementum eu, ornare ac, malesuada at, erat. Proin gravida orci porttitor enim accumsan lacinia. Donec condimentum, urna non molestie semper, ligula enim ornare nibh, quis laoreet eros quam eget ante. Aliquam libero. Vivamus nisl nibh, iaculis vitae, viverra sit amet, ullamcorper vitae, turpis. Aliquam erat volutpat. Vestibulum dui sem, pulvinar sed, imperdiet nec, iaculis nec, leo. Fusce odio. </p>
				<p>Etiam arcu dui, faucibus eget, placerat vel, sodales eget, orci. Donec ornare neque ac sem. Mauris aliquet. Aliquam sem leo, vulputate sed, convallis at, ultricies quis, justo. Donec nonummy magna quis risus. Quisque eleifend. Phasellus tempor vehicula justo. Aliquam lacinia metus ut elit. Suspendisse iaculis mauris nec lorem.<br />
				</p>
			</div>
			<p class="links"> <a href="#" class="more">Read More</a> <a href="#" class="comments">No Comments</a> </p>
		</div>
		<div class="post">
			<div class="title">
				<h2><a href="#">Praesent  condimentum</a></h2>
				<p><small>Posted on August 20th, 2007 by <a href="#">Free CSS Templates</a></small></p>
			</div>
			<div class="entry">
				<p>Etiam arcu dui, faucibus eget, placerat vel, sodales eget, orci. Donec ornare neque ac sem. Mauris aliquet. Aliquam sem leo, vulputate sed, convallis at, ultricies quis, justo. Donec nonummy magna quis risus. Quisque eleifend. Phasellus tempor vehicula justo. Aliquam lacinia metus ut elit. Suspendisse iaculis mauris nec lorem.</p>
				<ol>
					<li><a href="#">Integer sit amet pede vel arcu aliquet pretium.</a></li>
					<li><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</a></li>
					<li><a href="#">Phasellus nec erat sit amet nibh pellentesque congue.</a></li>
					<li><a href="#">Pellentesque quis elit non lectus gravida blandit. <br />
					</a></li>
				</ol>
			</div>
			<p class="links"><a href="#" class="more">Read More</a> <a href="#" class="comments">No Comments</a> </p>
		</div>
		<br style="clear: both;" />
	</div>
	<!-- end content -->
	<br style="clear: both;" />
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<p class="links">
		<a href="#" class="rss" title="Subscribe to entries web feed">Entries (<abbr title="Really Simple Syndication">RSS</abbr>)</a>
		&nbsp;&nbsp;&nbsp;
		<a href="#" class="rss" title="Subscribe to comments web feed">Entries (<abbr title="Really Simple Syndication">RSS</abbr>)</a>
		&nbsp;&nbsp;&nbsp;
		<a href="http://validator.w3.org/check/referer" class="xhtml" title="This page validates as XHTML">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a>
		&nbsp;&nbsp;&nbsp;
		<a href="http://jigsaw.w3.org/css-validator/check/referer" class="css" title="This page validates as CSS">Valid <abbr title="Cascading Style Sheets">CSS</abbr></a>
	</p>
	<p class="legal">
		&copy;2007 Exposure. All Rights Reserved.
		&nbsp;&nbsp;&bull;&nbsp;&nbsp;
		Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>
		&nbsp;&nbsp;&bull;&nbsp;&nbsp;
		Icons by <a href="http://famfamfam.com/">FAMFAMFAM</a>. </p>
</div>
<!-- end footer -->
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>
